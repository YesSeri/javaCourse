package com.zenkert.fb6.c;

import com.zenkert.fb6.c.p.Y;

public class X extends Y {
    private boolean x;
}

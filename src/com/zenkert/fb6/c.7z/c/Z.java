package com.zenkert.fb6.c;

public class Z {
    public double z;
}

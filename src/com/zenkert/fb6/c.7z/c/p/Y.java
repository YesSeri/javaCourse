package com.zenkert.fb6.c.p;

import com.zenkert.fb6.c.Z;

public class Y extends Z {
    protected String s;
}

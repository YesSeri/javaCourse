package com.zenkert.fb6.c.p;

public class W extends Y {
    int w;
}
